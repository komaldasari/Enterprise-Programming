package com.model;

import java.sql.Date;

public class customer {

  String firstname;
  String lastname;
  String email;
  Double phoneno;
  Double accountnum;
  Date dob;
  String passwd;
  public String getFirstname() {
    return firstname;
  }
  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }
  
  public String getLastname() {
    return lastname;
  }
  public void setLastname(String lastname) {
    this.lastname = lastname;
  }
  
  public String getEmail() {
    return email;
  }
  public void setEmail(String email) {
    this.email = email;
  }
  
  public Double getPhone() {
	return phoneno;
  }
  public void setPhone(Double phoneno) {
    this.phoneno = phoneno;
  }
  
  public Double getAccnum() {
    return accountnum;
  }
  public void setAccnum(Double accountnum) {
    this.accountnum = accountnum;
  }
  
  public Date getDob() {
    return dob;
  }
  public void setDob(Date dob) {
    this.dob = dob;
  }
  
  public String getPassword() {
    return passwd;
  }
  public void setPassword(String passwd) {
    this.passwd = passwd;
  }
  
}