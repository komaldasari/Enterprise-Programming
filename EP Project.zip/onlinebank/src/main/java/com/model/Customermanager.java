package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Customermanager {
 
  String url = "jdbc:mysql://localhost:3306/proj";
  String user = "root";
  String password = "root";
  Connection con = null;
  PreparedStatement ps = null;
  public String save(customer c) throws Exception {
    con = DriverManager.getConnection(url,user,password);
    ps = con.prepareStatement("insert into singup values(?,?,?,?,?,?,?)");
    ps.setString(1,c.getFirstname());
    ps.setString(2,c.getLastname());
    ps.setString(3,c.getEmail());
    ps.setDouble(4,c.getPhone());
    ps.setDouble(5,c.getAccnum());
    ps.setDate(6,c.getDob());
    ps.setString(7,c.getPassword());
      ps.execute();
    con.close();
    return "successfully register";
  }
  public String  login(customer c) throws SQLException{
    con = DriverManager.getConnection(url,user,password);
    ps = con.prepareStatement("select * from singup where email = ? and passwd = ?");
    ps.setString(1,c.getEmail());
    ps.setString(2,c.getPassword());
    ResultSet rs = ps.executeQuery();
    if(rs.next()) return rs.getString(1);
    return null;
    
  }
  
  public List<customer> showdata(customer c){
    List<customer> L = new ArrayList<customer>();
    try {
      con = DriverManager.getConnection(url,user,password);
      ps = con.prepareStatement("select * from singup where email = ? and passwd");
      ps.setString(1,c.getEmail());
      ps.setString(2,c.getPassword());
      ResultSet rs = ps.executeQuery();
      while(rs.next()) {
        c.setFirstname(rs.getString(1));
        c.setLastname(rs.getString(2));
        c.setEmail(rs.getString(3));
        c.setPhone(rs.getDouble(4));
        c.setAccnum(rs.getDouble(5));
        c.setDob(rs.getDate(6));
        c.setPassword(rs.getString(6));
        L.add(c);
      }
      
    }
    catch(Exception e) {
      
    }
    return L;
  }
  
  
}