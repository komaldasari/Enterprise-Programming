package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Customermanager;
import com.model.customer;



public class register extends HttpServlet {
  private static final long serialVersionUID = 1L;
       
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           customer c = new customer();
           Customermanager sm = new Customermanager();
         response.setContentType("text/html");
         PrintWriter pw= response.getWriter();
         try {
           String fn = request.getParameter("fisrtname");
           String ln = request.getParameter("lastname");
           String email = request.getParameter("email");
           String phonenum = request.getParameter("phoneno");
           String score = request.getParameter("score");
           Double phoneno = (phoneno == null) ? 0 : new Double(phoneno);
           String acnum = request.getParameter("accountnum");
           Double accountnum = (accountnum == null) ? 0 : new Double(accountnum);
           String DoB = request.getParameter("dob");
           String dateString = request.getParameter("submitDate");
           SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
           Date dob = DoB.parse(dateString);

           String ps = request.getParameter("password");
                c.setFirstname(fn);
                c.setLastname(ln);
                c.setEmail(email);
                c.setPassword(ps);
             String akn = sm.save(c);
             pw.print(akn);
         }
         catch(Exception e) {
           pw.print(e.getMessage());
         }
         RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
         rd.include(request, response);
  }

  
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
  }

}